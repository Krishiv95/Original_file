/* Login Reducer
 * handles login states in the app
 */
import CreateReducer from './CreateReducer';

const initialState = {
  data : null
};

console.log('call loginReducer');

export const LoginReducer = CreateReducer(initialState, {
  
  ['LOGIN_RESPONSE'](state, action) {
    console.log('call LoginReducer');
    console.log('state : ',state);
    console.log('action : ',action);
    return {
      data:action.payload
    };
  },
});
