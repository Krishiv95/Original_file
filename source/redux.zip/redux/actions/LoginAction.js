export function SaveLoginResponse (data) {
    console.log('call SaveLoginResponse : ', data)

    return {
        type: 'LOGIN_RESPONSE',
        payload: data,
    }
}
